import time, random
from CMC.settings import LOGGER




def random_sleep(min_sleep_time=1, max_sleep_time=3):
    sleep_time = random.randint(min_sleep_time, max_sleep_time)
    LOGGER.info(f'Random sleep: {sleep_time}')
    time.sleep(sleep_time)