from django.contrib import admin

# from home.models import user_details

# Register your models here.
# admin.site.register(user_details)