
[
    ['lumbermill',2,"36"],
    ['drilling_platform',4,"36"],
    ['tricycle',6,"36"],
    ['moving_van',7,"36"],
    ['missile',4,"f78a022e8ef54f1cb203ccf001990f84"],
    ['soap_dispenser',5,"f78a022e8ef54f1cb203ccf001990f84"],
    ['polecat',7,"f78a022e8ef54f1cb203ccf001990f84"],
    ['polecat',9,"f78a022e8ef54f1cb203ccf001990f84"],
    ['axolotl',4,"7128a9d0e339467ba6ce89df4ac5c933"],
    ['parachute',6,"7128a9d0e339467ba6ce89df4ac5c933"],
    ['kite',8,"7128a9d0e339467ba6ce89df4ac5c933"],
    ['black-footed_ferret',9,"7128a9d0e339467ba6ce89df4ac5c933"],
    ['solar_dish',1,"5270492226714330ad3072fd368ddfae"],
    ['half_track',2,"5270492226714330ad3072fd368ddfae"],
    ['hair_slide',4,"5270492226714330ad3072fd368ddfae"],

    ['streetcar',5,"4fcafa65937d4b5bb468f5e0db9e3ffe"],
    ['prison',6,"4fcafa65937d4b5bb468f5e0db9e3ffe"],

    ['wreck',4,"26c502b3bfb243e284d2ffd30e249f7d"],
    ['trailer_truck',7,"26c502b3bfb243e284d2ffd30e249f7d"],
    ['space_shuttle',9,"26c502b3bfb243e284d2ffd30e249f7d"],

    ['hair_slide',4,"5270492226714330ad3072fd368ddfae"],

]