
[
    ['lumbermill',"airplane","36_2"],
    ['drilling_platform',"ship","36_4"],
    ['tricycle',"bicycle","36_6"],
    ['moving_van',"car","36_7"],
    ['missile',"fish","f78a022e8ef54f1cb203ccf001990f84_4"],
    ['soap_dispenser',"panda","f78a022e8ef54f1cb203ccf001990f84_5"],
    ['polecat',"panda","f78a022e8ef54f1cb203ccf001990f84_7"],
    ['polecat',"panda","f78a022e8ef54f1cb203ccf001990f84_9"],
    ['axolotl',"fish","7128a9d0e339467ba6ce89df4ac5c933_4"],
    ['parachute',"dog","7128a9d0e339467ba6ce89df4ac5c933_6"],
    ['black-footed_ferret',"fish","7128a9d0e339467ba6ce89df4ac5c933_9"],
    ['solar_dish',"fish","5270492226714330ad3072fd368ddfae_1"],
    ['half_track',"cat","5270492226714330ad3072fd368ddfae_2"],
    ['hair_slide',"fish","5270492226714330ad3072fd368ddfae_4"],

    ['streetcar',"bus","4fcafa65937d4b5bb468f5e0db9e3ffe_5"],
    ['prison',"bus","4fcafa65937d4b5bb468f5e0db9e3ffe_6"],

    ['wreck',"ship","26c502b3bfb243e284d2ffd30e249f7d_4"],
    ['trailer_truck',"bus","26c502b3bfb243e284d2ffd30e249f7d_7"],

    ['monastery',"airplane","f44695eb7991492c815c680a4eb51e8f_2"],
    ['solar_dish',"bus","f44695eb7991492c815c680a4eb51e8f_5"],
    ['milk_can',"cicycle","f44695eb7991492c815c680a4eb51e8f_6"],

    ['wall_clock',"airplane","c0fe416955a94f4d83434add561bf45f_4"],

    ['drilling_platform',"ship","269cc23446f24e1c9a37ddf1d01c37b1_1"],
    ['passenger_car',"bus","269cc23446f24e1c9a37ddf1d01c37b1_4"],
    ['medicine_chest',"bicycle","269cc23446f24e1c9a37ddf1d01c37b1_5"],
    ['killer_whale',"airplane","269cc23446f24e1c9a37ddf1d01c37b1_9"],

    ['nail',"fish","fe9ce20cd1a0490eb8c78cc2656c3007_5"],

    ['dugong',"fish","97ae8cf1507340db8e898af8ce51c775_2"],

    ['flatworm',"fish","c3422b10161a4b5fac7120c92057d88e_7"],


    ['plate_rack',"fish","66489b0db17d4c58bccf4433424c6bf5_5"],


    ['tiger',"bird","cec20e2a411f46139965b56ceb0ca30f_1"],
    ['flatworm',"bird","cec20e2a411f46139965b56ceb0ca30f_9"],


]